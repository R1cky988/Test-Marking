import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router";
import { useGoBack } from "@/hooks/useGoBack";
import { ArrowLeft, Download, Edit3, Eye, Plus, RefreshCw, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";

import { MathJaxContent } from "@/components/rich-text/MathJaxContent";
import { RichTextEditor } from "@/components/rich-text/RichTextEditor";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { getApiErrorMessage } from "@/lib/apiErrorMessage";
import { useTranslation } from "react-i18next";
import type { QuestionBank } from "@/types/academic.types";
import {
  createQuestionBankItem,
  deleteQuestionBank,
  deleteQuestionBankItem,
  getQuestionBank,
  getQuestionBankItems,
  importQuestionBankFile,
  type QuestionBankItem,
  updateQuestionBank,
  updateQuestionBankItem,
} from "../questionBanks.api";

const labels = ["A", "B", "C", "D", "E"];

function normalizeAnswer(value: string | string[]) {
  return Array.isArray(value) ? value.join(",") : value;
}

function createEmptyForm() {
  return {
    content: "",
    options: ["", "", "", ""],
    correctAnswers: ["A"],
    difficulty: "medium",
    topic: "",
  };
}

function isTinyMceFloatingUiEvent(event: Event) {
  const target = event.target;
  const targetSelectors = [
    ".tox-tinymce-aux",
    ".tox-silver-sink",
    ".tox-menu",
    ".tox-dialog-wrap",
    ".tox-dialog",
    ".tox-pop",
    ".tox-tooltip",
  ].join(",");
  const openSelectors = [".tox-menu", ".tox-dialog-wrap", ".tox-pop", ".tox-tooltip"].join(",");

  if (target instanceof HTMLElement && target.closest(targetSelectors)) return true;

  return Array.from(document.querySelectorAll<HTMLElement>(openSelectors)).some((element) => {
    const style = window.getComputedStyle(element);
    return style.display !== "none" && style.visibility !== "hidden" && element.getClientRects().length > 0;
  });
}

export function QuestionBankDetailPage() {
  const { t } = useTranslation();
  const { bankId } = useParams();
  const goBack = useGoBack("/question-banks");
  const [bank, setBank] = useState<QuestionBank | null>(null);
  const [items, setItems] = useState<QuestionBankItem[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [editingItem, setEditingItem] = useState<QuestionBankItem | null>(null);
  const [deletingItem, setDeletingItem] = useState<QuestionBankItem | null>(null);
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [deleteBankOpen, setDeleteBankOpen] = useState(false);
  const [form, setForm] = useState(createEmptyForm());
  const [infoName, setInfoName] = useState("");
  const [infoDescription, setInfoDescription] = useState("");
  const [importResult, setImportResult] = useState<string>("");
  const [selectedImportFile, setSelectedImportFile] = useState<File | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importInputKey, setImportInputKey] = useState(0);
  const [search, setSearch] = useState("");
  const [difficultyFilter, setDifficultyFilter] = useState("all");
  const [topicFilter, setTopicFilter] = useState("");
  const difficultyText = useMemo(
    () => ({
      easy: t("questionBanks.easy"),
      medium: t("questionBanks.medium"),
      hard: t("questionBanks.hard"),
    }),
    [t],
  );

  const totalPages = useMemo(() => Math.max(1, Math.ceil(total / 10)), [total]);

  function resetImportDialogState() {
    setSelectedImportFile(null);
    setImportResult("");
    setImportInputKey((key) => key + 1);
  }

  async function loadBank() {
    if (!bankId) return;
    const loaded = await getQuestionBank(bankId);
    setBank(loaded);
    setInfoName(loaded.name);
    setInfoDescription(loaded.description ?? "");
  }

  async function loadItems(
    nextPage = page,
    filters: { search?: string; difficulty?: string; topic?: string } = {},
  ) {
    if (!bankId) return;
    const activeSearch = filters.search ?? search;
    const activeDifficulty = filters.difficulty ?? difficultyFilter;
    const activeTopic = filters.topic ?? topicFilter;
    try {
      setIsLoading(true);
      const response = await getQuestionBankItems(bankId, {
        page: nextPage,
        limit: 10,
        search: activeSearch.trim() || undefined,
        difficulty: activeDifficulty === "all" ? undefined : activeDifficulty,
        topic: activeTopic.trim() || undefined,
      });
      setItems(response.data);
      setTotal(response.meta.total);
      setPage(response.meta.page);
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.detail.loadFailed')));
    } finally {
      setIsLoading(false);
    }
  }

  async function loadAll() {
    try {
      await Promise.all([loadBank(), loadItems(1)]);
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.detail.loadFailed')));
    }
  }

  useEffect(() => {
    void loadAll();
  }, [bankId]);

  function openCreateItem() {
    setEditingItem(null);
    setForm(createEmptyForm());
    setItemDialogOpen(true);
  }

  function openEditItem(item: QuestionBankItem) {
    setEditingItem(item);
    setForm({
      content: item.content,
      options: [...item.options, "", "", "", "", ""].slice(0, Math.max(4, item.options.length)),
      correctAnswers: Array.isArray(item.correct_answer) ? item.correct_answer : [item.correct_answer],
      difficulty: item.difficulty,
      topic: item.topic ?? "",
    });
    setItemDialogOpen(true);
  }

  async function saveItem() {
    if (!bankId) return;
    const options = form.options.map((option) => option.trim()).filter(Boolean);
    if (!form.content.trim() || options.length < 2 || form.correctAnswers.length === 0) {
      toast.error(t('questionBanks.detail.validationFailed'));
      return;
    }

    const itemData = {
      content: form.content,
      options,
      correctAnswer: form.correctAnswers.length === 1 ? form.correctAnswers[0] : form.correctAnswers,
      difficulty: form.difficulty,
      topic: form.topic.trim() || "general",
    };

    try {
      if (editingItem) {
        await updateQuestionBankItem(editingItem.id, itemData);
        toast.success(t('questionBanks.detail.updated'));
      } else {
        await createQuestionBankItem({ bankId, ...itemData });
        toast.success(t('questionBanks.detail.created'));
      }
      setItemDialogOpen(false);
      await Promise.all([loadBank(), loadItems(page)]);
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.detail.saveFailed')));
    }
  }

  async function confirmDeleteItem() {
    if (!deletingItem) return;
    try {
      await deleteQuestionBankItem(deletingItem.id);
      toast.success(t('questionBanks.detail.deletedItem'));
      setDeletingItem(null);
      await Promise.all([loadBank(), loadItems(page)]);
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.detail.deleteFailed')));
    }
  }

  async function updateInfo() {
    if (!bankId || !infoName.trim()) return;
    try {
      await updateQuestionBank(bankId, { name: infoName.trim(), description: infoDescription.trim() });
      toast.success(t('questionBanks.detail.infoUpdated'));
      await loadBank();
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.detail.infoUpdateFailed')));
    }
  }

  async function confirmDeleteBank() {
    if (!bankId) return;
    try {
      await deleteQuestionBank(bankId);
      toast.success(t('questionBanks.detail.deletedBank'));
      window.location.href = "/teacher/question-banks";
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.deleteFailed')));
    }
  }

  async function importFile() {
    if (!bankId || !selectedImportFile) {
      toast.error(t("questionBanks.detail.import.fileRequired"));
      return;
    }
    try {
      setIsImporting(true);
      const result = await importQuestionBankFile(bankId, selectedImportFile);
      setImportResult(t('questionBanks.detail.importSuccess', { count: result.imported }));
      toast.success(t('questionBanks.detail.importDone'));
      setSelectedImportFile(null);
      setImportInputKey((key) => key + 1);
      await Promise.all([loadBank(), loadItems(1)]);
    } catch (error) {
      setImportResult(getApiErrorMessage(error, t('questionBanks.detail.importFailed')));
      toast.error(getApiErrorMessage(error, t('questionBanks.detail.importFailed')));
    } finally {
      setIsImporting(false);
    }
  }

  async function downloadTemplate() {
    try {
      const XLSX = await import("xlsx");
      const workbook = XLSX.utils.book_new();
      const columns = t("questionBanks.detail.import.columns", { returnObjects: true }) as string[];
      const sampleRows = t("questionBanks.detail.import.sampleRows", { returnObjects: true }) as Array<Array<string | number>>;
      const guideRows = t("questionBanks.detail.import.guideRows", { returnObjects: true }) as string[][];
      const dataSheet = XLSX.utils.aoa_to_sheet([
        columns,
        ...sampleRows,
      ]);
      dataSheet["!cols"] = [
        { wch: 8 },
        { wch: 52 },
        { wch: 24 },
        { wch: 24 },
        { wch: 24 },
        { wch: 24 },
        { wch: 24 },
        { wch: 16 },
        { wch: 16 },
        { wch: 22 },
      ];

      const guideSheet = XLSX.utils.aoa_to_sheet(guideRows);
      guideSheet["!cols"] = [{ wch: 24 }, { wch: 16 }, { wch: 88 }];

      XLSX.utils.book_append_sheet(workbook, dataSheet, t("questionBanks.detail.import.sheetQuestions"));
      XLSX.utils.book_append_sheet(workbook, guideSheet, t("questionBanks.detail.import.sheetGuide"));

      XLSX.writeFile(workbook, t("questionBanks.detail.import.templateFileName"), {
        bookType: "xlsx",
        compression: true,
      });
    } catch (error) {
      toast.error(getApiErrorMessage(error, t("questionBanks.detail.import.templateFailed")));
    }
  }

  return (
    <div className="space-y-6">
      <button onClick={goBack} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" />
        {t('questionBanks.detail.back')}
      </button>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">{bank?.name ?? t('questionBanks.title')}</h1>
          <p className="mt-1 line-clamp-2 max-w-full overflow-hidden break-words text-muted-foreground">
            {bank?.description || t('questionBanks.subtitle')}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => void loadAll()}>
            <RefreshCw className="h-4 w-4" />
            {t('questionBanks.detail.refresh')}
          </Button>
          <Button variant="outline" className="gap-2" onClick={() => setImportDialogOpen(true)}>
            <Upload className="h-4 w-4" />
            {t('questionBanks.detail.importFile')}
          </Button>
          <Button className="gap-2" onClick={openCreateItem}>
            <Plus className="h-4 w-4" />
            {t('questionBanks.detail.add')}
          </Button>
        </div>
      </div>

      {bank && (
        <div className="grid gap-3 md:grid-cols-4">
          <Card><CardContent className="p-4">{t('questionBanks.detail.totalQuestions')}: <b>{bank.items_count}</b></CardContent></Card>
          <Card><CardContent className="p-4">{t('questionBanks.easy')}: <b>{bank.difficulty_counts.easy}</b></CardContent></Card>
          <Card><CardContent className="p-4">{t('questionBanks.detail.mediumLabel')}: <b>{bank.difficulty_counts.medium}</b></CardContent></Card>
          <Card><CardContent className="p-4">{t('questionBanks.hard')}: <b>{bank.difficulty_counts.hard}</b></CardContent></Card>
        </div>
      )}

      <Tabs defaultValue="items" className="space-y-4">
        <TabsList>
          <TabsTrigger value="items">{t('questionBanks.detail.tabQuestions')}</TabsTrigger>
          <TabsTrigger value="info">{t('questionBanks.detail.tabInfo')}</TabsTrigger>
        </TabsList>

        <TabsContent value="items" className="space-y-4">
          <Card>
            <CardContent className="grid gap-3 p-4 md:grid-cols-[1fr_180px_220px_auto]">
              <div className="space-y-2">
                <Label>{t('questionBanks.detail.search')}</Label>
                <Input
                  value={search}
                  placeholder={t('questionBanks.detail.searchPlaceholder')}
                  onChange={(event) => setSearch(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") void loadItems(1);
                  }}
                />
              </div>
              <div className="space-y-2">
                <Label>{t('questionBanks.detail.difficulty')}</Label>
                <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('questionBanks.detail.all')}</SelectItem>
                    <SelectItem value="easy">{t('questionBanks.easy')}</SelectItem>
                    <SelectItem value="medium">{t('questionBanks.medium')}</SelectItem>
                    <SelectItem value="hard">{t('questionBanks.hard')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t('questionBanks.detail.topic')}</Label>
                <Input
                  value={topicFilter}
                  placeholder={t('questionBanks.detail.itemDialog.topicPlaceholder')}
                  onChange={(event) => setTopicFilter(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") void loadItems(1);
                  }}
                />
              </div>
              <div className="flex items-end gap-2">
                <Button onClick={() => void loadItems(1)}>{t('questionBanks.detail.filter')}</Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearch("");
                    setDifficultyFilter("all");
                    setTopicFilter("");
                    void loadItems(1, { search: "", difficulty: "all", topic: "" });
                  }}
                >
                  {t('questionBanks.detail.clearFilter')}
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="overflow-auto rounded-md border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">{t('questionBanks.detail.table.index')}</TableHead>
                  <TableHead>{t('questionBanks.detail.table.content')}</TableHead>
                  <TableHead className="w-32">{t('questionBanks.detail.table.answer')}</TableHead>
                  <TableHead className="w-32">{t('questionBanks.detail.table.difficulty')}</TableHead>
                  <TableHead className="w-40">{t('questionBanks.detail.table.topic')}</TableHead>
                  <TableHead className="w-32">{t('questionBanks.detail.table.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading && <TableRow><TableCell colSpan={6} className="h-24 text-center">{t('questionBanks.detail.loading')}</TableCell></TableRow>}
                {!isLoading && items.map((item, index) => (
                  <TableRow key={item.id}>
                    <TableCell>{(page - 1) * 10 + index + 1}</TableCell>
                    <TableCell className="max-w-[520px]">
                      <MathJaxContent html={item.content} className="line-clamp-3 text-sm" />
                    </TableCell>
                    <TableCell>{normalizeAnswer(item.correct_answer)}</TableCell>
                    <TableCell><Badge variant="outline">{difficultyText[item.difficulty]}</Badge></TableCell>
                    <TableCell>{item.topic || "-"}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="icon" onClick={() => openEditItem(item)}><Edit3 className="h-4 w-4" /></Button>
                        <Button variant="outline" size="icon" className="text-danger-foreground" onClick={() => setDeletingItem(item)}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end gap-2">
            <Button variant="outline" disabled={page <= 1} onClick={() => void loadItems(page - 1)}>{t('questionBanks.detail.prev')}</Button>
            <span className="text-sm text-muted-foreground">{page}/{totalPages}</span>
            <Button variant="outline" disabled={page >= totalPages} onClick={() => void loadItems(page + 1)}>{t('questionBanks.detail.next')}</Button>
          </div>
        </TabsContent>

        <TabsContent value="info">
          <Card>
            <CardContent className="space-y-4 p-4">
              <div className="space-y-2">
                <Label>{t('questionBanks.detail.infoName')}</Label>
                <Input value={infoName} onChange={(event) => setInfoName(event.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>{t('questionBanks.detail.infoDesc')}</Label>
                <Textarea value={infoDescription} onChange={(event) => setInfoDescription(event.target.value)} />
              </div>
              <div className="flex justify-between">
                <Button variant="destructive" onClick={() => setDeleteBankOpen(true)}>{t('questionBanks.delete')}</Button>
                <Button variant="success" onClick={() => void updateInfo()}>{t('questionBanks.detail.updateInfo')}</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog
        modal={false}
        open={itemDialogOpen}
        onOpenChange={(open) => {
          if (!open && isTinyMceFloatingUiEvent(new Event("tinymce-check"))) return;
          setItemDialogOpen(open);
        }}
      >
        <DialogContent
          className="flex h-[100dvh] max-h-[100dvh] w-[100dvw] max-w-none flex-col overflow-hidden rounded-none p-0"
          onInteractOutside={(event) => {
            if (isTinyMceFloatingUiEvent(event)) {
              event.preventDefault();
            }
          }}
          onPointerDownOutside={(event) => {
            if (isTinyMceFloatingUiEvent(event.detail.originalEvent)) {
              event.preventDefault();
            }
          }}
          onFocusOutside={(event) => {
            if (isTinyMceFloatingUiEvent(event)) {
              event.preventDefault();
            }
          }}
        >
          <DialogHeader className="shrink-0 border-b px-6 py-4 pr-12">
            <DialogTitle>{editingItem ? t('questionBanks.detail.itemDialog.editTitle') : t('questionBanks.detail.itemDialog.createTitle')}</DialogTitle>
          </DialogHeader>
          <div className="min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">
            <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_minmax(340px,420px)]">
              <div className="min-w-0 space-y-4">
                <div className="space-y-2">
                  <Label>{t('questionBanks.detail.itemDialog.contentLabel')}</Label>
                  <RichTextEditor value={form.content} onChange={(content) => setForm((current) => ({ ...current, content }))} />
                </div>
                <div className="grid gap-3 md:grid-cols-2">
                  {form.options.map((option, index) => (
                    <div key={index} className="space-y-2">
                      <Label>{t('questionBanks.detail.itemDialog.choiceLabel', { label: labels[index] })}</Label>
                      <RichTextEditor
                        minHeight={120}
                        value={option}
                        onChange={(value) =>
                          setForm((current) => ({
                            ...current,
                            options: current.options.map((item, itemIndex) => (itemIndex === index ? value : item)),
                          }))
                        }
                      />
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-4">
                  {labels.slice(0, form.options.length).map((label) => (
                    <Label key={label} className="flex items-center gap-2">
                      <Checkbox
                        checked={form.correctAnswers.includes(label)}
                        onCheckedChange={(checked) =>
                          setForm((current) => ({
                            ...current,
                            correctAnswers: checked
                              ? [...current.correctAnswers, label]
                              : current.correctAnswers.filter((answer) => answer !== label),
                          }))
                        }
                      />
                      {label}
                    </Label>
                  ))}
                  {form.options.length < 5 && <Button type="button" variant="outline" onClick={() => setForm((current) => ({ ...current, options: [...current.options, ""] }))}>{t('questionBanks.detail.itemDialog.addE')}</Button>}
                </div>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>{t('questionBanks.detail.itemDialog.difficultyLabel')}</Label>
                    <Select value={form.difficulty} onValueChange={(difficulty) => setForm((current) => ({ ...current, difficulty }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">{t('questionBanks.easy')}</SelectItem>
                        <SelectItem value="medium">{t('questionBanks.medium')}</SelectItem>
                        <SelectItem value="hard">{t('questionBanks.hard')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>{t('questionBanks.detail.itemDialog.topicLabel')}</Label>
                    <Input value={form.topic} onChange={(event) => setForm((current) => ({ ...current, topic: event.target.value }))} />
                  </div>
                </div>
              </div>

              <aside className="min-w-0 rounded-md border bg-muted/20 xl:sticky xl:top-0 xl:max-h-[calc(100dvh-10rem)] xl:overflow-y-auto">
                <div className="flex items-center justify-between gap-2 border-b px-4 py-3">
                  <div className="flex items-center gap-2 text-sm font-semibold">
                    <Eye className="h-4 w-4 text-muted-foreground" />
                    Preview
                  </div>
                  <Badge variant="outline">{difficultyText[form.difficulty as keyof typeof difficultyText] ?? form.difficulty}</Badge>
                </div>
                <div className="space-y-4 p-4">
                  <div className="rounded-md border bg-background p-3">
                    <div className="mb-2 text-xs font-medium uppercase text-muted-foreground">Câu hỏi</div>
                    {form.content.trim() ? (
                      <MathJaxContent html={form.content} className="prose max-w-none text-sm" />
                    ) : (
                      <p className="text-sm text-muted-foreground">Chưa có nội dung câu hỏi</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    {form.options.map((option, index) => {
                      const label = labels[index];
                      const isCorrect = form.correctAnswers.includes(label);
                      return (
                        <div
                          key={label}
                          className={`rounded-md border bg-background p-3 ${isCorrect ? "border-success/60 bg-success/5" : ""}`}
                        >
                          <div className="mb-2 flex items-center gap-2">
                            <Badge variant="outline" className={isCorrect ? "border-success/60 bg-success/10 text-success" : undefined}>{label}</Badge>
                            {isCorrect && <span className="text-xs font-medium text-success">Đáp án đúng</span>}
                          </div>
                          {option.trim() ? (
                            <MathJaxContent html={option} className="prose max-w-none text-sm" />
                          ) : (
                            <p className="text-sm text-muted-foreground">Chưa có nội dung đáp án</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </aside>
            </div>
          </div>
          <DialogFooter className="shrink-0 border-t px-6 py-4">
            <Button type="button" variant="outline" onClick={() => setItemDialogOpen(false)}>{t('questionBanks.detail.itemDialog.cancel')}</Button>
            <Button type="button" variant="success" onClick={() => void saveItem()}>{t('questionBanks.detail.itemDialog.save')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={importDialogOpen}
        onOpenChange={(open) => {
          setImportDialogOpen(open);
          resetImportDialogState();
        }}
      >
        <DialogContent className="max-w-xl">
          <DialogHeader><DialogTitle>{t('questionBanks.detail.import.title')}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="rounded-md border bg-brand-soft p-4 text-sm text-info-foreground">
              <div className="font-medium">{t('questionBanks.detail.import.formatTitle')}</div>
              <p className="mt-1">{t('questionBanks.detail.import.formatLine1')}</p>
              <p className="mt-1">{t('questionBanks.detail.import.formatLine2')}</p>
              <p className="mt-1">{t("questionBanks.detail.import.acceptedXlsx")}</p>
            </div>
            <Button variant="outline" className="w-full gap-2 sm:w-auto" onClick={() => void downloadTemplate()}>
              <Download className="h-4 w-4" />
              {t('questionBanks.detail.exportTemplate')}
            </Button>
            <div className="space-y-2">
              <Label>{t("questionBanks.detail.import.fileLabel")}</Label>
              <Input
                key={`question-bank-import-${importInputKey}`}
                type="file"
                accept=".xlsx,.csv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                onChange={(event) => {
                  setImportResult("");
                  setSelectedImportFile(event.target.files?.[0] ?? null);
                }}
              />
              {selectedImportFile && (
                <div className="rounded-md border bg-muted/40 p-3 text-sm">
                  {t("questionBanks.detail.import.selectedFile", { name: selectedImportFile.name })}
                </div>
              )}
            </div>
            {importResult && <div className="rounded-md border bg-muted/40 p-3 text-sm">{importResult}</div>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setImportDialogOpen(false)} disabled={isImporting}>
              {t('questionBanks.detail.import.close')}
            </Button>
            <Button onClick={() => void importFile()} disabled={!selectedImportFile || isImporting}>
              {isImporting ? t("questionBanks.detail.import.importing") : t("questionBanks.detail.import.confirm")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(deletingItem)} onOpenChange={(open) => !open && setDeletingItem(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>{t('questionBanks.detail.deleteDialog.title')}</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">{t('questionBanks.detail.itemDeleteDesc')}</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingItem(null)}>{t('questionBanks.detail.deleteDialog.cancel')}</Button>
            <Button variant="destructive" onClick={() => void confirmDeleteItem()}>{t('questionBanks.detail.deleteDialog.confirm')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteBankOpen} onOpenChange={setDeleteBankOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>{t('questionBanks.deleteDialog.title')}</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">{t('questionBanks.deleteDialog.desc')}</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteBankOpen(false)}>{t('questionBanks.deleteDialog.cancel')}</Button>
            <Button variant="destructive" onClick={() => void confirmDeleteBank()}>{t('questionBanks.deleteDialog.confirm')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
