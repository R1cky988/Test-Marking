import { useEffect, useState } from "react";
import { Link } from "react-router";
import { Edit3, Eye, Plus, RefreshCw, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { getApiErrorMessage } from "@/lib/apiErrorMessage";
import { useTranslation } from "react-i18next";
import type { QuestionBank } from "@/types/academic.types";
import {
  createQuestionBank,
  deleteQuestionBank,
  getQuestionBanks,
  updateQuestionBank,
} from "../questionBanks.api";

export function QuestionBanksListPage() {
  const { t, i18n } = useTranslation();
  const locale = i18n.language === "en" ? "en-US" : "vi-VN";

  function formatDate(value: string | null) {
    if (!value) return t('common.dash');
    return new Intl.DateTimeFormat(locale).format(new Date(value));
  }

  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [editingBank, setEditingBank] = useState<QuestionBank | null>(null);
  const [bankDialogOpen, setBankDialogOpen] = useState(false);
  const [deletingBank, setDeletingBank] = useState<QuestionBank | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  async function loadBanks() {
    try {
      setIsLoading(true);
      setBanks(await getQuestionBanks());
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.loadFailed')));
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    void loadBanks();
  }, []);

  function openCreateDialog() {
    setEditingBank(null);
    setName("");
    setDescription("");
    setBankDialogOpen(true);
  }

  function openEditDialog(bank: QuestionBank) {
    setEditingBank(bank);
    setName(bank.name);
    setDescription(bank.description ?? "");
    setBankDialogOpen(true);
  }

  async function saveBank() {
    if (!name.trim()) {
      toast.error(t('questionBanks.nameRequired'));
      return;
    }

    try {
      if (editingBank) {
        await updateQuestionBank(editingBank.id, { name: name.trim(), description: description.trim() });
        toast.success(t('questionBanks.updated'));
      } else {
        await createQuestionBank({ name: name.trim(), description: description.trim() });
        toast.success(t('questionBanks.created'));
      }
      setEditingBank(null);
      setBankDialogOpen(false);
      setName("");
      setDescription("");
      await loadBanks();
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.saveFailed')));
    }
  }

  async function confirmDelete() {
    if (!deletingBank) return;
    try {
      await deleteQuestionBank(deletingBank.id);
      toast.success(t('questionBanks.deleteSuccess'));
      setDeletingBank(null);
      await loadBanks();
    } catch (error) {
      toast.error(getApiErrorMessage(error, t('questionBanks.deleteFailed')));
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-semibold text-foreground">{t('questionBanks.title')}</h1>
          <p className="mt-1 text-muted-foreground">{t('questionBanks.subtitle')}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" disabled={isLoading} onClick={() => void loadBanks()}>
            <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            {t('questionBanks.refresh')}
          </Button>
          <Button className="gap-2" onClick={openCreateDialog}>
            <Plus className="h-4 w-4" />
            {t('questionBanks.create')}
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {banks.map((bank) => (
          <Card key={bank.id} className="min-w-0">
            <CardHeader className="space-y-2">
              <div className="flex min-w-0 items-start justify-between gap-3">
                <CardTitle className="min-w-0 truncate text-lg">{bank.name}</CardTitle>
                <Badge className="shrink-0">{t('questionBanks.questionsCount', { count: bank.items_count })}</Badge>
              </div>
              {bank.description && (
                <p className="line-clamp-2 max-w-full overflow-hidden break-words text-sm text-muted-foreground">
                  {bank.description}
                </p>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-2 text-sm">
                <div className="rounded-md bg-muted/40 p-2">{t('questionBanks.easy')}: {bank.difficulty_counts.easy}</div>
                <div className="rounded-md bg-muted/40 p-2">{t('questionBanks.medium')}: {bank.difficulty_counts.medium}</div>
                <div className="rounded-md bg-muted/40 p-2">{t('questionBanks.hard')}: {bank.difficulty_counts.hard}</div>
              </div>
              <div className="text-sm text-muted-foreground">{t('questionBanks.createdAt')}: {formatDate(bank.created_at)}</div>
              <div className="flex flex-wrap gap-2">
                <Link to={`/teacher/question-banks/${bank.id}`}>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Eye className="h-4 w-4" />
                    {t('questionBanks.viewDetails')}
                  </Button>
                </Link>
                <Button variant="outline" size="sm" className="gap-2" onClick={() => openEditDialog(bank)}>
                  <Edit3 className="h-4 w-4" />
                  {t('questionBanks.edit')}
                </Button>
                <Button variant="outline" size="sm" className="gap-2 text-red-600" onClick={() => setDeletingBank(bank)}>
                  <Trash2 className="h-4 w-4" />
                  {t('questionBanks.delete')}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {!isLoading && banks.length === 0 && (
        <div className="rounded-md border bg-card p-10 text-center text-muted-foreground">{t('questionBanks.empty')}</div>
      )}

      <Dialog open={bankDialogOpen} onOpenChange={setBankDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingBank ? t('questionBanks.dialog.editTitle') : t('questionBanks.dialog.createTitle')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t('questionBanks.dialog.nameLabel')}</Label>
              <Input value={name} onChange={(event) => setName(event.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>{t('questionBanks.dialog.descLabel')}</Label>
              <Textarea value={description} onChange={(event) => setDescription(event.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBankDialogOpen(false)}>{t('questionBanks.dialog.cancel')}</Button>
            <Button onClick={() => void saveBank()}>{t('questionBanks.dialog.save')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(deletingBank)} onOpenChange={(open) => !open && setDeletingBank(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{t('questionBanks.deleteDialog.title')}</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">{t('questionBanks.deleteDialog.desc')}</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingBank(null)}>{t('questionBanks.deleteDialog.cancel')}</Button>
            <Button variant="destructive" onClick={() => void confirmDelete()}>{t('questionBanks.deleteDialog.confirm')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
