import axiosClient from "@/api/axiosClient";
import type {
  ApiSingleResponse,
  JsonValue,
  Question,
  QuestionInput,
} from "@/types/academic.types";

interface RawQuestionOption {
  id: string;
  questionId?: string;
  question_id?: string;
  content: string;
  isCorrect?: boolean;
  is_correct?: boolean;
  orderIndex?: number;
  order_index?: number;
}

interface RawQuestion {
  id: string;
  examId?: string;
  exam_id?: string;
  questionBankItemId?: string | null;
  question_bank_item_id?: string | null;
  orderIndex?: number;
  order_index?: number;
  content: string;
  attachments?: JsonValue | null;
  explanation?: string | null;
  options?: RawQuestionOption[] | string[];
  correctAnswer?: string | string[] | null;
  correct_answer?: string | string[] | null;
  difficulty?: string | null;
  topic?: string | null;
  snapshot?: JsonValue | null;
}

interface ImportQuestionsResult {
  imported: number;
  skipped: number;
  errors: Array<{ row?: number; reason: string }>;
  questions: RawQuestion[];
}

interface PreviewQuestionOption {
  label: string;
  content: string;
  is_correct: boolean;
}

interface PreviewQuestionRow {
  question_number: number;
  content: string;
  explanation: string | null;
  attachments: JsonValue | null;
  options: PreviewQuestionOption[];
  correct_answer: string;
}

interface PreviewQuestionsResult {
  total_questions: number;
  choices_per_question: number;
  questions: PreviewQuestionRow[];
}

function normalizeQuestion(raw: RawQuestion): Question {
  const correctAnswers = normalizeAnswerList(raw.correct_answer ?? raw.correctAnswer);
  const rawOptions = raw.options ?? [];
  const options = rawOptions.map((option, index) => {
    if (typeof option === "string") {
      return {
        id: `${raw.id}-${index}`,
        question_id: raw.id,
        content: option,
        is_correct: correctAnswers.includes(choiceLabel(index)),
        order_index: index,
      };
    }

    return {
      id: option.id,
      question_id: option.question_id ?? option.questionId ?? raw.id,
      content: option.content,
      is_correct: option.is_correct ?? option.isCorrect ?? false,
      order_index: option.order_index ?? option.orderIndex ?? 0,
    };
  });

  return {
    id: raw.id,
    exam_id: raw.exam_id ?? raw.examId ?? "",
    question_bank_item_id: raw.question_bank_item_id ?? raw.questionBankItemId ?? null,
    order_index: raw.order_index ?? raw.orderIndex ?? 0,
    content: raw.content,
    attachments: raw.attachments ?? null,
    explanation: raw.explanation ?? null,
    options,
    correct_answer: raw.correct_answer ?? raw.correctAnswer ?? (correctAnswers.length === 1 ? correctAnswers[0] : correctAnswers),
    difficulty: raw.difficulty ?? null,
    topic: raw.topic ?? null,
    snapshot: raw.snapshot ?? null,
  };
}

function choiceLabel(index: number): string {
  return String.fromCharCode(65 + index);
}

function normalizeAnswerList(answer: string | string[] | null | undefined): string[] {
  if (!answer) return [];
  return (Array.isArray(answer) ? answer : [answer])
    .flatMap((item) => String(item).split(","))
    .map((item) => item.trim().toUpperCase())
    .filter(Boolean);
}

export async function getExamQuestions(examId: string): Promise<Question[]> {
  const { data } = await axiosClient.get<ApiSingleResponse<RawQuestion[]>>(
    `/web/exams/${examId}/questions`,
  );
  return data.data.map(normalizeQuestion);
}

export async function getExamVersionQuestions(examId: string, versionId: string): Promise<Question[]> {
  const { data } = await axiosClient.get<ApiSingleResponse<RawQuestion[]>>(
    `/web/exams/${examId}/versions/${versionId}/questions`,
  );
  return data.data.map(normalizeQuestion);
}

export async function saveExamQuestionsBulk(
  examId: string,
  questions: QuestionInput[],
): Promise<Question[]> {
  const { data } = await axiosClient.post<ApiSingleResponse<RawQuestion[]>>(
    `/web/exams/${examId}/questions/bulk`,
    { questions },
  );
  return data.data.map(normalizeQuestion);
}

export const createBulkQuestions = saveExamQuestionsBulk;

export async function updateQuestion(
  questionId: string,
  payload: Partial<QuestionInput> & { confirm_regrade?: boolean },
): Promise<{ question: Question; warnings: string[]; regrading_jobs: string[] }> {
  const { data } = await axiosClient.put<
    ApiSingleResponse<RawQuestion> & {
      warnings?: string[];
      regrading_jobs?: string[];
    }
  >(`/web/questions/${questionId}`, payload);

  return {
    question: normalizeQuestion(data.data),
    warnings: data.warnings ?? [],
    regrading_jobs: data.regrading_jobs ?? [],
  };
}

export async function updateExamQuestionSnapshot(
  examQuestionId: string,
  payload: {
    snapshot?: {
      content?: string;
      options?: string[];
      correct_answer?: string | string[];
      correctAnswer?: string | string[];
    };
    content?: string;
    options?: string[];
    correct_answer?: string | string[];
    correctAnswer?: string | string[];
    confirm_regrade?: boolean;
  },
): Promise<{ question: Question; warnings: string[]; regrading_jobs: string[] }> {
  const { data } = await axiosClient.put<
    ApiSingleResponse<RawQuestion> & {
      warnings?: string[];
      regrading_jobs?: string[];
    }
  >(`/web/exam-questions/${examQuestionId}`, payload);

  return {
    question: normalizeQuestion(data.data),
    warnings: data.warnings ?? [],
    regrading_jobs: data.regrading_jobs ?? [],
  };
}

export async function reorderExamQuestions(examId: string, order: string[], versionId?: string): Promise<Question[]> {
  const { data } = await axiosClient.put<ApiSingleResponse<RawQuestion[]>>(
    `/web/exams/${examId}/questions/reorder`,
    { order, version_id: versionId },
  );
  return data.data.map(normalizeQuestion);
}

export async function downloadQuestionTemplate(examId: string): Promise<Blob> {
  const { data } = await axiosClient.get(
    `/web/exams/${examId}/exports/question-template`,
    { responseType: "blob" },
  );
  return data;
}

export async function previewImportQuestionsExcel(
  examId: string,
  file: File,
): Promise<{ total_questions: number; choices_per_question: number; questions: QuestionInput[] }> {
  const formData = new FormData();
  formData.append("file", file);

  const { data } = await axiosClient.post<ApiSingleResponse<PreviewQuestionsResult>>(
    `/web/exams/${examId}/questions/import/preview`,
    formData,
    { headers: { "Content-Type": "multipart/form-data" } },
  );

  return {
    total_questions: data.data.total_questions,
    choices_per_question: data.data.choices_per_question,
    questions: data.data.questions.map((question) => ({
      content: question.content,
      attachments: question.attachments ?? undefined,
      explanation: question.explanation ?? undefined,
      options: question.options.map((option, index) => ({
        content: option.content,
        is_correct: option.is_correct,
        order_index: index,
      })),
    })),
  };
}

export async function previewImportQuestionsExcelByShape(params: {
  total_questions: number;
  choices_per_question: number;
  file: File;
}): Promise<{ total_questions: number; choices_per_question: number; questions: QuestionInput[] }> {
  const formData = new FormData();
  formData.append("file", params.file);
  formData.append("total_questions", String(params.total_questions));
  formData.append("choices_per_question", String(params.choices_per_question));

  const { data } = await axiosClient.post<ApiSingleResponse<PreviewQuestionsResult>>(
    "/web/questions/import/preview",
    formData,
    { headers: { "Content-Type": "multipart/form-data" } },
  );

  return {
    total_questions: data.data.total_questions,
    choices_per_question: data.data.choices_per_question,
    questions: data.data.questions.map((question) => ({
      content: question.content,
      attachments: question.attachments ?? undefined,
      explanation: question.explanation ?? undefined,
      options: question.options.map((option, index) => ({
        content: option.content,
        is_correct: option.is_correct,
        order_index: index,
      })),
    })),
  };
}

export async function importQuestionsExcel(
  examId: string,
  file: File,
): Promise<{ imported: number; skipped: number; errors: Array<{ row?: number; reason: string }>; questions: Question[] }> {
  const formData = new FormData();
  formData.append("file", file);

  const { data } = await axiosClient.post<ApiSingleResponse<ImportQuestionsResult>>(
    `/web/exams/${examId}/questions/import`,
    formData,
    { headers: { "Content-Type": "multipart/form-data" } },
  );

  return {
    imported: data.data.imported,
    skipped: data.data.skipped,
    errors: data.data.errors,
    questions: data.data.questions.map(normalizeQuestion),
  };
}
