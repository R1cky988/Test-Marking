import axiosClient from "@/api/axiosClient";
import type { ApiSingleResponse, PaginatedResponse, QuestionBank } from "@/types/academic.types";

interface RawQuestionBank {
  id: string;
  name: string;
  description?: string | null;
  teacherId?: string;
  teacher_id?: string;
  itemsCount?: number;
  items_count?: number;
  difficultyCounts?: QuestionBank["difficulty_counts"];
  difficulty_counts?: QuestionBank["difficulty_counts"];
  createdAt?: string | null;
  created_at?: string | null;
  updatedAt?: string | null;
  updated_at?: string | null;
}

export interface QuestionBankItem {
  id: string;
  bank_id: string;
  content: string;
  options: string[];
  correct_answer: string | string[];
  difficulty: "easy" | "medium" | "hard";
  topic: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export interface QuestionBankItemInput {
  bankId: string;
  content: string;
  options: string[];
  correctAnswer: string | string[];
  difficulty: string;
  topic?: string;
}

export type QuestionBankItemUpdateInput = Omit<QuestionBankItemInput, "bankId">;

function normalizeBank(raw: RawQuestionBank): QuestionBank {
  return {
    id: raw.id,
    name: raw.name,
    description: raw.description ?? null,
    teacher_id: raw.teacher_id ?? raw.teacherId ?? "",
    items_count: raw.items_count ?? raw.itemsCount ?? 0,
    difficulty_counts: raw.difficulty_counts ?? raw.difficultyCounts ?? { easy: 0, medium: 0, hard: 0 },
    created_at: raw.created_at ?? raw.createdAt ?? null,
    updated_at: raw.updated_at ?? raw.updatedAt ?? null,
  };
}

export async function getQuestionBanks(): Promise<QuestionBank[]> {
  const { data } = await axiosClient.get<ApiSingleResponse<RawQuestionBank[]>>("/web/question-banks");
  return data.data.map(normalizeBank);
}

export async function getQuestionBank(bankId: string): Promise<QuestionBank> {
  const { data } = await axiosClient.get<ApiSingleResponse<RawQuestionBank>>(`/web/question-banks/${bankId}`);
  return normalizeBank(data.data);
}

export async function createQuestionBank(payload: { name: string; description?: string }): Promise<QuestionBank> {
  const { data } = await axiosClient.post<ApiSingleResponse<RawQuestionBank>>("/web/question-banks", payload);
  return normalizeBank(data.data);
}

export async function updateQuestionBank(
  bankId: string,
  payload: { name?: string; description?: string },
): Promise<QuestionBank> {
  const { data } = await axiosClient.put<ApiSingleResponse<RawQuestionBank>>(`/web/question-banks/${bankId}`, payload);
  return normalizeBank(data.data);
}

export async function deleteQuestionBank(bankId: string): Promise<void> {
  await axiosClient.delete(`/web/question-banks/${bankId}`);
}

export async function getQuestionBankItems(
  bankId: string,
  params: { page?: number; limit?: number; search?: string; difficulty?: string; topic?: string } = {},
): Promise<PaginatedResponse<QuestionBankItem>> {
  const { data } = await axiosClient.get<PaginatedResponse<QuestionBankItem>>(`/web/question-banks/${bankId}/items`, {
    params,
  });
  return data;
}

export async function createQuestionBankItem(payload: QuestionBankItemInput): Promise<QuestionBankItem> {
  const { data } = await axiosClient.post<ApiSingleResponse<QuestionBankItem>>("/web/question-bank-items", payload);
  return data.data;
}

export async function updateQuestionBankItem(
  itemId: string,
  payload: Partial<QuestionBankItemUpdateInput>,
): Promise<QuestionBankItem> {
  const { data } = await axiosClient.put<ApiSingleResponse<QuestionBankItem>>(`/web/question-bank-items/${itemId}`, payload);
  return data.data;
}

export async function deleteQuestionBankItem(itemId: string): Promise<void> {
  await axiosClient.delete(`/web/question-bank-items/${itemId}`);
}

export async function uploadQuestionBankRichTextImage(file: File): Promise<string> {
  const formData = new FormData();
  formData.append("file", file);
  const { data } = await axiosClient.post<ApiSingleResponse<{ file_url?: string; location?: string }>>(
    "/web/question-bank-items/image",
    formData,
    { headers: { "Content-Type": "multipart/form-data" } },
  );
  const url = data.data.location ?? data.data.file_url;
  if (!url) throw new Error("Upload response is missing image URL");
  return url;
}

export async function importQuestionBankFile(bankId: string, file: File): Promise<{ imported: number }> {
  const formData = new FormData();
  formData.append("file", file);
  const { data } = await axiosClient.post<ApiSingleResponse<{ imported: number }>>(
    `/web/question-banks/${bankId}/import`,
    formData,
    { headers: { "Content-Type": "multipart/form-data" } },
  );
  return data.data;
}
